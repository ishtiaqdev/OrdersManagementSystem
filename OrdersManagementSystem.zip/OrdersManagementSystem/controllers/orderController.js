const express = require('express');
var router = express.Router();
const mongoose = require('mongoose');
const Order = mongoose.model('Order');
const path = require('path');
const multer = require('multer');
const fs = require('fs');


// GET request for main summary of ordered items page.
router.get('/', ordered_items_count);

// GET request for creating order.
router.get('/create', order_create_get);

// POST request for creating Order.
router.post('/create', order_create_update_post);

// GET request to update Order.
router.get('/update/:id', order_update_get);

// POST request to update Order.
router.post('/update/:id', order_create_update_post);

// GET request for list of all Order items.
router.get('/list', order_list_get);

// post request for list of all Order items.
router.post('/list', order_list_post);

// GET request for list of all Order items from a specific company or to a specific address.
router.get('/specificorders/:recipient', specific_order_list_get);

// GET request for deleting all orders once
router.get('/delete', order_delete_all)

// GET request to delete Order by _id.
router.get('/delete/:id', order_delete_get);

// GET request to delete by an Order Id.
router.post('/deletebyid', order_deletebyid_post);

// GET request for creating Orders from uploaded file.
router.get('/upload', order_upload_get);

//used for storing uploaded file to path.
var storage = multer.diskStorage({
    destination: (req, file, callback) => {
        var dir = './uploads';
        if (!fs.existsSync(dir)){
            fs.mkdirSync(dir);
        }
        callback(null, dir)
    },
    filename: (req, file, callback) => {
        callback(null, file.originalname);
    }
});

//will be using this for uplading
const upload = multer({ storage: storage });

// POST request for creating Orders from uploaded file.
router.post('/upload', upload.single('fileOrders'), order_upload_post);




function order_create_get(req, res) {
    res.render("order/addOrEdit", {
        title: "Add Order"
    });
}

function order_create_update_post(req, res) {
    if (req.body._id == '')
        insertRecord(null, req, res);
    else
        updateRecord(null, req, res);
}

function order_update_get(req, res) {
    Order.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("order/addOrEdit", {
                title: "Update Order",
                order: doc
            });
        }
    });
}

function order_list_manual(source, message, req, res) {
    Order.find((err, docs) => {
        if (!err) {
            if(source != null)
            {
                if(source == "searchwordempty" || source == "deletebyidempty" || source == "deleteallno") {
                    res.render("order/list", {
                        list: docs,
                        searchDeleteError: message
                    });
                }
                else {
                    res.render("order/list", {
                        list: docs,
                        fileUploaded: message
                    });
                }
            }
            else {
                res.render("order/list", {
                    list: docs,
                    fileUploaded: message
                });
            }
        }
        else {
            console.log('Error in retrieving order list :' + err);
        }
    });
}

function order_list_get(req, res) {
    order_list_manual(null, null, req, res);
}

function specific_order_list_get(req, res) {
    if( req.params.recipient != "")
    {
        Order.find({ $text: { $search: req.params.recipient }}, (err, docs) => { 
            if (!err) {
                res.render("order/list", {
                    list: docs
                });
            }
            else {
                console.log('Error in retrieving order list :' + err);
                res.statusCode = 500;
                return res.json({
                    errors: ['Failed to load data']
                });
            }
        });
    }
}

function order_list_post(req, res) {
    if(req.body.hasOwnProperty('filter'))
    {
        if(req.body.filter != "")
        {
            Order.find({ $text: { $search: req.body.filter }}, (err, docs) => { 
                if (!err) {
                    res.render("order/list", {
                        list: docs
                    });
                }
                else {
                    console.log('Error in retrieving order list :' + err);
                }
            });   
        }
        else {
            order_list_manual("searchwordempty", "Please enter a Word to search.", req, res)
        }
    }
    else if(req.body.hasOwnProperty('orderId'))
    {
        if( req.body.orderId != "")
        {
            Order.find({ "orderId": req.body.orderId }, (err, docs) => { 
                if (!err) {
                    if(docs.length > 0)
                    {
                        if(docs.length > 1)
                        {
                            let documents = [];
                            docs.forEach((doc) => {
                                documents.push(doc.orderId)
                            });
                            Order.deleteMany({ orderId: { $in: documents }}, (err, doc) => {
                                if (!err) {
                                    order_list_manual("deletebyid", "All " + docs.length + " orders with orderId = " + req.body.orderId + " have been deleted successfully!", req, res);
                                }
                                else { console.log('Error in order delete :' + err); }
                            });
                        }
                        else 
                        {
                            let documents = [];
                            docs.forEach((doc) => {
                                documents.push(doc.orderId)
                            });
                            Order.deleteOne({ orderId: { $in: documents }}, (err, doc) => {
                                if (!err) {
                                    order_list_manual("deletebyid", "" +  docs.length + " order with orderId = " + req.body.orderId + " has been deleted successfully!", req, res);
                                }
                                else { console.log('Error in order delete :' + err); }
                            });
                        }
                    }
                }
                else {
                    console.log('Error in retrieving order list :' + err);
                }
            });
        }
        else {
            order_list_manual("deletebyidempty", "Please enter a Order Id to delete.", req, res)
        }
    }
}

function order_upload_get(req, res) {
    res.render("order/fileUpload", {
        title: "Add Orders by File Upload"
    });
}

function order_upload_post(req, res) {
    if(req.file != undefined)
    {
        if(req.file.filename != "")
        {
            if(req.file.filename.match(/\.(txt)$/i))
            {
                var dir = './uploads';
                if (!fs.existsSync(dir)){
                    fs.mkdirSync(dir);
                }

                let filePath = path.normalize(__dirname.substring(0, __dirname.indexOf('controller')) + '/uploads/' + req.file.filename);
                let ordersData = fs.readFileSync(filePath, 'UTF8');
                
                //This is the core function of algorithm for reading all data and making separate orders.
                let orders = segregateOrders(ordersData);

                if(orders.length > 0)
                {
                    try{
                        insertRecord(orders, req, res);
                    }
                    catch (err) {
                        console.log(err);
                    }
                }
            }
            else
            {
                req.body['fileUploadError'] = "Uploaded file is not a recognized format. Only this format is allowed: .txt"
                res.render("order/fileUpload", {
                    title: "Add Orders by File Upload",
                    upload: req.body
                });
            }
        }
    }
    else
    {
        req.body['fileUploadError'] = "Please choose a file to upload."
        res.render("order/fileUpload", {
            title: "Add Orders by File Upload",
            upload: req.body
        });
    }
}

function segregateOrders(orders) {
    //Array for storing all orders.
    let orderObjects = [];
    if(orders != null) {
        //This will hold current property in loop of 4.
        let currentProperty = '';

        //There are two solution algorithms as per my assumptions, both algorithms' code are written blow.
        //Algorithm 1: First scenario is assuming that all the data will be provided in plain text with or without new lines \n and no
        //             carriage returns \r like available in second scenario and orderId will be in sequence like in data sample provided.
        //Algorithm 2: Second scenario is assuming that the data will be provided in same format like when copying data provided from 
        //             PDF test file to notepad and then parsing it which contains new lines \n and carriage returns \r.

        //Algorithm 1:
        //Splitting the text by number of lines if more than 1 line exist
        let numberOfLines = (orders.indexOf('\n') > -1 ? orders.split('\n') : [orders]);
        let remainingData = '';
        let currentLineCSVs; //Contains Comma Separated Values of current line.
        let orderIdSequence = orders.split(',')[0]; // Assuming that all orderId values will be in sequence.
        let propertyCounter = 0; //It will be used to check last property

        for(let line = 0; line < numberOfLines.length; line++)
        {
            remainingData += numberOfLines[line]; //appending current line to remainingData.
            currentLineCSVs = (remainingData.indexOf(',') > -1 ? remainingData.split(',') : [remainingData]);//splitting to CSVs

            while(currentLineCSVs.length >= 4)
            {
                let order = new Order();
                order.orderId = '';
                order.companyName = '';
                order.customerAdress = ''
                order.orderedItem = '';

                //Loop 4 times to find all properties
                for(let i=0; i < 4; i++)
                {
                    propertyCounter++;
                    if(propertyCounter == 4) //Last property
                    {
                        let currentSplitValues = currentLineCSVs[0].trim().split(' '); //Splitted values of last property
                        if(currentSplitValues.length > 1) //If more than 1 value exist
                        {
                            let nextOrderId = currentSplitValues[currentSplitValues.length - 1]; //Getting last value which is orderId
                            let nextOrderIdInNumber = parseInt(nextOrderId);
                            if(!isNaN(nextOrderIdInNumber)) //Ensuring that nextOrderId is number.
                            {
                                if(parseInt(orderIdSequence) + 1 == nextOrderIdInNumber)
                                {
                                    propertyCounter = 0;
                                    orderIdSequence = nextOrderId;
                                    currentProperty = currentSplitValues.slice(0, currentSplitValues.length - 1).join(' ');
                                    currentLineCSVs = currentLineCSVs.slice(1, currentLineCSVs.length);
                                    currentLineCSVs.unshift(nextOrderId); //inserting next orderId at the start of currentLineCSVs
                                    remainingData = remainingData.substring(currentProperty.length + 1, remainingData.length).trim();
                                }   
                            }
                        }
                    }
                    if(propertyCounter != 0 && propertyCounter != 4)//Ensuring default value propertyCounter = 0 or it's last property
                    {
                        currentProperty = currentLineCSVs[0].trim();
                        currentLineCSVs = currentLineCSVs.slice(1, currentLineCSVs.length);
                        remainingData = remainingData.substring(currentProperty.length + 1, remainingData.length).trim();
                    }
                    switch (i) {
                        case 0: order.orderId = currentProperty.toString(); break; //0 means first property
                        case 1: order.companyName = currentProperty; break; //1 means second property
                        case 2: order.customerAdress = currentProperty; break; //2 means third property
                        case 3: order.orderedItem = currentProperty; break; //3 means fourth property
                        default:
                    }
                }
                orderObjects.push(order);
            }
        }


        //Algorithm 2:
        //Splitting the text by number of lines if more than 1 line exist
        // let numberOfLines = (orders.indexOf('\n') > -1 ? orders.split('\n') : [orders]);
        // let remainingData = '';
        // let currentLineCSVs; //Contains Comma Separated Values of current line.

        // for(let line = 0; line < numberOfLines.length; line++)
        // {
        //     remainingData += numberOfLines[line];
        //     currentLineCSVs = (remainingData.indexOf(',') > -1 ? remainingData.split(',') : [remainingData]);

        //     while(currentLineCSVs.length >= 4)
        //     {
        //         let order = new Order();
        //         order.orderId = '';
        //         order.companyName = '';
        //         order.customerAdress = ''
        //         order.orderedItem = '';

        //         //Loop 4 times to find all properties
        //         for(let i=0; i < 4; i++)
        //         {
        //             //If next value is Carriage Return, that means orderId is attached with orderedItem of current value. 
        //             if(currentLineCSVs[1] == '\r')
        //             {
        //                 //Splitting it with space and getting first value as orderedItem.
        //                 currentProperty = currentLineCSVs[0].split(' ').slice(0, currentLineCSVs[0].split(' ').length - 1).join(' ').trim();
        //                 currentLineCSVs = [currentLineCSVs[0].split(' ').slice(currentLineCSVs[0].split(' ').length - 1, currentLineCSVs[0].split(' ').length).join(' ').trim()];
        //                 //Getting all remaining substring strarting from the position of next to current property. 
        //                 remainingData = remainingData.substring(currentProperty.length + 1, remainingData.length).trim();
        //             }
        //             else {
        //                 currentProperty = currentLineCSVs[0].trim();
        //                 currentLineCSVs = currentLineCSVs.slice(1, currentLineCSVs.length);
        //                 remainingData = remainingData.substring(currentProperty.length + 1, remainingData.length).trim();
        //             }
        //             switch (i) {
        //                 case 0: order.orderId = currentProperty.toString(); break; //0 means first property
        //                 case 1: order.companyName = currentProperty; break; //1 means second property
        //                 case 2: order.customerAdress = currentProperty; break; //2 means third property
        //                 case 3: order.orderedItem = currentProperty; break; //3 means fourth property
        //                 default:
        //             }
        //         }
        //         orderObjects.push(order);
        //     }
        // }
    }
    return orderObjects;
}

function order_delete_all(req, res) {
    Order.deleteMany({}, (err, doc) => {
        if (!err) {
            if(doc.deletedCount > 0)
                order_list_manual("deleteall", "All orders have been deleted successfully!", req, res);
            else
                order_list_manual("deleteallno", "No orders available to delete!", req, res);
        }
        else { console.log('Error in order delete :' + err); }
    });
}

function order_delete_get(req, res) {
    Order.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            order_list_manual("deleteone", "One order has been deleted successfully!", req, res);
        }
        else { console.log('Error in order delete :' + err); }
    });
}

function order_deletebyid_post(req, res) {
    
}

function insertRecord(ordersToSave, req, res) {
    let orders = prepareOrdersDocuments(ordersToSave, req, res);
    if(orders.length > 0)
    {
        Order.collection.insert(orders, function (err, docs) {
            if (err){
                if (err.name == 'ValidationError') {
                    handleValidationError(null, null, err, req.body);
                    res.render("order/addOrEdit", {
                        title: "Add Order",
                        order: req.body
                    });
                }
                else
                    console.log('Error during record insertion : ' + err);
            } else {
                if(orders.length > 1)
                {
                    console.log("Multiple documents inserted to Collection");
                    order_list_manual("insertall", "File uploaded and " + orders.length + " orders have been saved to database successfully!", req, res);
                }
                else if (orders.length > 0)
                {
                    console.log("Single document inserted to Collection");
                    order_list_manual("insertone", "1 order has been inserted successfully!", req, res);
                }
              
            }
        })
    }
}

function prepareOrdersDocuments(ordersToSave, req, res) {
    var orders = [];
    if(ordersToSave != null) {
        if(ordersToSave.length > 0)
        {
            ordersToSave.forEach((order) => {
                orders.push({ orderId: order.orderId, 
                    companyName: order.companyName, 
                    customerAdress: order.customerAdress, 
                    orderedItem: order.orderedItem })
            })
        }
    }
    else {
        let order = {   orderId: req.body.orderId != "" ? req.body.orderId : handleValidationError("orderId", "Order Id is required.", null, req.body), 
                        companyName: req.body.companyName != "" ? req.body.companyName : handleValidationError("companyName", "Company Name is required.", null, req.body), 
                        customerAdress: req.body.customerAdress != "" ? req.body.customerAdress : handleValidationError("customerAdress", "Customer Adress is required.", null, req.body), 
                        orderedItem: req.body.orderedItem != "" ? req.body.orderedItem : handleValidationError("orderedItem", "Ordered Item is required.", null, req.body) }
        
        if (req.body.orderId == "" || req.body.companyName == "" || req.body.customerAdress == "" || req.body.orderedItem == "")
        {
            res.render("order/addOrEdit", {
                title: "Add Order",
                order: req.body
            });
        }
        else {
            orders.push(order);
        }
    }
    return orders;
}

function updateRecord(ordersToUpdate, req, res) {
    Order.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { 
            order_list_manual("updateone", "Order has been updated successfully!", req, res); 
        }
        else {
            if (err.name == 'ValidationError') {
                handleValidationError(null, null, err, req.body);
                res.render("order/addOrEdit", {
                    title: 'Update Order',
                    order: req.body
                });
            }
            else
                console.log('Error during record update : ' + err);
        }
    });
}

async function ordered_items_count(req, res) {
    let count = await Order.aggregate([
        {
            "$group": {
                _id: "$orderedItem" ,
                "counts": { "$sum": 1 },
            },
        }, { $sort: { "counts": -1, "orderId": 1 } }
    ])
    res.render("order/itemsCount", {
        title: "How Often Ordered Items",
        data: count
    });
}

function handleValidationError(filedName, fieldMessage, err, body) {
    if(err != null)
    {
        for (field in err.errors) {
            switch (err.errors[field].path) {
                case 'orderId':
                    body['orderIdError'] = err.errors[field].message;
                    break;
                case 'companyName':
                    body['companyNameError'] = err.errors[field].message;
                    break;
                case 'customerAdress':
                    body['customerAdressError'] = err.errors[field].message;
                    break;
                case 'orderedItem':
                    body['orderedItemError'] = err.errors[field].message;
                    break;
                case 'fileUpload':
                    body['fileUploadError'] = err.errors[field].message;
                    break;
                default:
                    break;
            }
        }
    }
    else if(filedName != null && filedName != "")
    {
        switch (filedName) {
            case 'orderId':
                body['orderIdError'] = fieldMessage;
                break;
            case 'companyName':
                body['companyNameError'] = fieldMessage;
                break;
            case 'customerAdress':
                body['customerAdressError'] = fieldMessage;
                break;
            case 'orderedItem':
                body['orderedItemError'] = fieldMessage;
                break;
            case 'fileUpload':
                body['fileUploadError'] = fieldMessage;
                break;
            default:
                break;
        }
    }
}

module.exports = router;
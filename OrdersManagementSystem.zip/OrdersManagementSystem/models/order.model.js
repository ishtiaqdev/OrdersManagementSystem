const mongoose = require('mongoose');

var orderSchema = new mongoose.Schema({
    orderId: {
        type: String,
        required: 'Order Id is required'
    },
    companyName: {
        type: String,
        required: 'Company Name is required.'
    },
    customerAdress: {
        type: String,
        required: 'Customer Address is required.'
    },
    orderedItem: {
        type: String,
        required: 'Customer Address is required.'
    }
});
orderSchema.index({"$**":"text"})

mongoose.model('Order', orderSchema);